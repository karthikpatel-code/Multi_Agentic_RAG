import os
import glob
from openai import AzureOpenAI
# import sys
# __import__("pysqlite3")
# sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
import chromadb
import pandas as pd
import json  




client = AzureOpenAI(
    api_key = "",
    api_version = "",
    azure_endpoint = ""
)

def oai_embedder(text):
    embedding = client.embeddings.create(input = text, model='text-embedding-ada-002')
    # embedding = client.embeddings.create(model='text-embedding-ada-002', input=text)['data'][0]['embedding']
    return embedding

def create_croma_embedings(chunkedfiles_path):
    chroma_root = r"chromadb"
    os.makedirs(os.path.join(os.getcwd(),chroma_root),exist_ok=True)
    chroma_client = chromadb.PersistentClient(path=chroma_root)
    colname = 'RAG'
    croma_col = chroma_client.get_or_create_collection(name=colname)
    csv_root_dir = os.path.join(os.getcwd(),"temp",chunkedfiles_path,"chunkedfiles")
    print(csv_root_dir)
    print(os.listdir(csv_root_dir))
    all_files = glob.glob(os.path.join(csv_root_dir, "*.xlsx"))
    df1 = pd.concat((pd.read_excel(f) for f in all_files))


    df1['title'] = df1['title'].astype('str')
    df1['sectionHeading'] = df1['sectionHeading'].astype('str')
    df1['documentName'] = df1['documentName'].astype('str')
    df1['chunkUUID'] = df1['chunkUUID'].astype('str')
    df1.reset_index(inplace = True, drop = True)
    print(f'Total entries - {df1.shape[0]}')
    emblist = []
    df1["content"] = df1["content"].replace("<br>","\n")

    for ix in df1.index:
        emb = oai_embedder(df1.loc[ix]['content']).data[0].embedding
        # emb = oai_embedder(df1.loc[ix]['content'])
        emblist.append(emb)
    ids = df1.index.astype("str").tolist()
    documents = df1['content'].tolist()
    documents = [w.replace('<br>', '\n') for w in documents]
    metadatas = df1.apply(lambda z: {"documentName":z[9], "title":z[1], "sectionHeading":z[2], "pageNumber":z[7], "partNumber":z[4],"chunkUUID": z[6]}, axis=1).tolist()
    embeddings = emblist

    old_cnt = croma_col.count()
    croma_col.add(ids = ids, documents=documents, embeddings=embeddings, metadatas=metadatas)
    new_cnt = croma_col.count()
    print(f'added {new_cnt-old_cnt} entries in collection-{croma_col} Successfully\n---\n')
    return f"Collection {colname}, created in cromadb and embeddings are stored in Vector database and Data Ingestion completed successfully....."


