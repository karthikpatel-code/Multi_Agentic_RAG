from chunker_api_final import smart_chunker
import os
import pandas as pd
import time
from pathlib import Path
import json



def extract_and_chunk(conversation_id,doc_list):
    base_output_path=os.path.join(os.getcwd(),"temp",conversation_id, "generated_output")
    os.makedirs(base_output_path,exist_ok=True)
    base_output_path1=os.path.join(os.getcwd(),"temp",conversation_id, "chunkedfiles")
    os.makedirs(base_output_path1,exist_ok=True)
    for doc in doc_list:
        folder_name = os.path.join(os.getcwd(),"temp",conversation_id)
        filename = doc
        requestSessionId = ""
        cloudName = ""
        azureEndpoint = ""
        azureKey = ""
        chunkTokenSize = 1024
        response_data = smart_chunker(folder_name, filename, requestSessionId, cloudName, azureEndpoint, azureKey,chunkTokenSize)
        data = list(response_data.values())[0]["chunkData"]
        # write the data for debugging
        # with open("data/vector_data/input_data.json", "w") as f:
        #     json.dump(data, f)

        for chunk_no, obj in enumerate(data):
            del obj["chunkBoundingBox"]
            del obj["documentClass"]
            del obj["chunkType"]
            #obj["sno"] = f"{file_num}_{chunk_no}"
            obj["documentName"] = Path(filename).name

        # print(data)
        df = pd.DataFrame(data)
        chunkedfiles = os.path.join(os.getcwd(),"temp",conversation_id, "chunkedfiles",doc.replace('.pdf','') +".xlsx")
        df.to_excel(chunkedfiles,index = False)
        time.sleep(5)
    
    return f"Chunked files are created and stored in folder {conversation_id}"


