import json
import os
import warnings
from datetime import datetime
import pandas as pd
import sqlite3
import os
import json

from typing import List
from fastapi import FastAPI, Form, Request, UploadFile
from fastapi.responses import JSONResponse,StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
import uvicorn
import json
import ssl
from dotenv import load_dotenv
load_dotenv()
import asyncio
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_core import CancellationToken
from agent_team import MagenticOne
from addon_agents import LLMUsageTracker
import logging
from autogen_core import EVENT_LOGGER_NAME

# Set up the logging configuration to use the custom handler
logger = logging.getLogger(EVENT_LOGGER_NAME)
logger.setLevel(logging.INFO)
llm_usage = LLMUsageTracker()
logger.handlers = [llm_usage]

os.system("playwright install --with-deps chromium")

from db.initialize_db import init_db

warnings.filterwarnings('ignore')
warnings.warn('DelftStack')
warnings.warn('Do not show this message')

app = FastAPI(debug=False)
app.add_middleware(CORSMiddleware,allow_origins = ["*"],allow_methods = ["*"],allow_headers = ["*"])
app.secret_key = os.urandom(24)
app.add_middleware(SessionMiddleware, secret_key=app.secret_key)
templates = Jinja2Templates(directory="templates")

conversation_queue={}

############## MagenticOne Orchestrator

async def execute_workflow(task,config,w_id,conv_id,conv_type):
	global conversation_queue
	try:
		import datetime
		import pytz
		conn = sqlite3.connect(os.path.join(os.getcwd(),'db','data_tables.db'))  
		cursor=conn.cursor()
		tools={}
		if w_id=="Data Ingestion":
			tools=["extract_and_chunk","generate_embeddings_and_store"]
		else:
			tools=["context_retriever"]

		model_client = AzureOpenAIChatCompletionClient(
            azure_endpoint=os.environ["azure_endpoint"],
            model=os.environ["orchestrator_model"],
            azure_5deployment=os.environ["orchestrator_model"],
            api_key=os.environ["api_key"],
            api_version=os.environ["api_version"],
			temperature=0.0001,
			top_p=0.001,
			seed=42
		)

		m1=None
		if config!=None:
			m1 = MagenticOne(client=model_client,tools=tools,file_surfer_required=config["file_surfer_required"],web_surfer_required=config["web_surfer_required"])
		else:
			m1 = MagenticOne(client=model_client,tools=tools)
		#result = await Console(m1.run_stream(task=task))
		stream=None
		cancellation_token=None
		if conv_type=="New":
			cancellation_token = CancellationToken()
			conversation_queue[conv_id]=cancellation_token
			stream = m1.run_stream(task=task,cancellation_token=cancellation_token)
		else:
			res=cursor.execute("select message from conv_logs where type='Conv State' and conv_id=?",(conv_id,)).fetchone()[0]
			conv_state=json.loads(res)
			#print(conv_state)
			await m1.load_state(conv_state)
			stream = m1.run_stream(task=task,cancellation_token=conversation_queue[conv_id])	
		team_id=m1._team_id	
		async for message in stream:
			#print(message)
			if hasattr(message,"source"):	
				if hasattr(message,"target"):	
					print(message.target)		
				model=os.environ["azure_endpoint"] + os.environ["orchestrator_model"]
				import uuid
				cursor.execute('INSERT INTO conv_logs VALUES(?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),conv_id,team_id,w_id,message.content,message.type,message.source,model,datetime.datetime.now(pytz.utc),))
				conn.commit()
				print(json.dumps({"source":message.source,"content":message.content,"type":message.type}))
				yield json.dumps({"source":message.source,"content":message.content,"type":message.type})
			else:
				import shutil
				try:

					if os.path.exists(os.path.join(os.getcwd(),"temp",conv_id)):
						shutil.rmtree(os.path.join(os.getcwd(),"temp",conv_id))
				except:
					pass
				print(json.dumps({"source":"Orchestrator","content":"End","type":"TaskMessage"}))
				yield json.dumps({"source":"Orchestrator","content":"End","type":"TaskMessage"})
		conv_state=await m1.save_state()
		if conv_type=="New":
			cursor.execute('INSERT INTO conv_logs VALUES(?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),conv_id,team_id,w_id,json.dumps(conv_state),"Conv State","Log","",datetime.datetime.now(pytz.utc),))
		else:
			cursor.execute('UPDATE conv_logs set message=? and row_timestamp=? where conv_id=?',(json.dumps(conv_state),datetime.datetime.now(pytz.utc),conv_id,))
		conn.commit()
	except asyncio.CancelledError:
		print("Interrupted")


############## FASTAPI Routes

@app.post('/runtask') 
async def execute_task_api(file: List[UploadFile]=[],query: str = Form(...)):
	doc_list=[]
	#print(file)
	#print(query)
	query=json.loads(query)
	conversation_id=str(query["conv_id"])
	conv_type=query["conv_type"]
	print("-----------------file---------------",file)
	print(file)
	if len(file)>0:
		base_path=os.path.join(os.getcwd(),"temp",conversation_id)
		os.makedirs(base_path,exist_ok=True)
		for doc in file:
			file_path=os.path.join(base_path,doc.filename)					
			with(open(file_path,'wb')) as f:
				f.write(doc.file.read())
			doc_list.append(doc.filename)
	
	prompt="Conversation ID: " + conversation_id + "\n""User Query: " + query["query"]
	config=None
	if conv_type=="New":
		if query["workflowid"]=="Data Ingestion":
			w_prompt="""- Check if attachments are present; if missing, request them from the user.
- Extract content from the provided documents and chunk the text into manageable parts.
- Retrieve and store the folder name that contains the file with chunked content.
- Generate embeddings for the chunked content using an embedding model.
- Store the embeddings in a vector store.
- Confirm that the data ingestion process is successful and return a completion message to the user."""
		elif query["workflowid"]=="Query Processing":
			w_prompt="""Receive the user query and initiate processing.
- Retrieve relevant context from the vector store based on the query.
- Extract key details from the retrieved information for better accuracy.
- Generate a concise and factual response using the extracted details.
- If no relevant context is found, inform the user instead of generating incorrect information.
- Return the final response to the user."""
			if query["query"]!="":
				prompt=prompt + "\nWorkflow rules to execute:\n" + w_prompt
			# config["logs_dir"]=os.path.join(os.getcwd(),"my_logs")
	if len(doc_list)>0:
		prompt=prompt + "\n\n###### Document Name:\n\n" + "\n".join([elem for elem in doc_list])
	return StreamingResponse(execute_workflow(prompt,config,w_id=query["workflowid"],conv_id=conversation_id,conv_type=conv_type),media_type="application/json")

async def fetch_table_data(table_name: str = None):
	conn = sqlite3.connect(os.path.join(os.getcwd(), 'db', 'data_tables.db'))  
	cursor = conn.cursor()
	cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
	tables = [row[0] for row in cursor.fetchall()] 
	data, column_names = None, None
	if table_name and table_name in tables:  
		cursor.execute(f"SELECT * FROM {table_name}")  
		column_names = [desc[0] for desc in cursor.description]
		data = cursor.fetchall()

	conn.close()
	return tables, data, column_names, table_name


@app.get("/tables", response_class=HTMLResponse)
@app.post("/tables", response_class=HTMLResponse)
async def tables_api(request: Request, table: str = Form(None)):
    """Retrieve tables and render the 'edit_tables.html' template."""
    tables, data, column_names, selected_table = await fetch_table_data(table)
    
    return templates.TemplateResponse(
        "edit_tables.html",  
        {
            "request": request,
            "tables": tables,
            "data": data,
            "column_names": column_names,
            "selected_table": selected_table
        }
    )

# init_db()
if __name__ == "__main__":
	uvicorn.run(app, host='localhost', port=8000)
