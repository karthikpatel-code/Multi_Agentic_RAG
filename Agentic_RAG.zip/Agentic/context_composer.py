
import chromadb
from openai import AzureOpenAI
import os
import pandas as pd



def oai_embedder(text):
    client = AzureOpenAI(
    api_key = 'b6fc0e27cb1b4435b7119d60ca20a5cb',
    api_version = "2023-08-01-preview",
    azure_endpoint = "https://aoai-wef-ea-ai-prod-canada-east.openai.azure.com/"
    )
    # openai.api_type = "azure"
    # openai.api_version = "2023-08-01-preview"
    # openai.api_base = "https://aoai-wef-ea-ai-prod-canada-east.openai.azure.com/" # Add your endpoint here
    # openai.api_key = 'b6fc0e27cb1b4435b7119d60ca20a5cb'
    embedding = client.embeddings.create(input=text, model='text-embedding-ada-002').data[0].embedding
    return embedding


def where_maker(documentName, chunkUUID):
    where_filter = {
        "$and": [
            {
                "documentName": {
                    "$eq": documentName
                }
            },
            {
                "chunkUUID": {
                    "$eq": chunkUUID
                }
            }
        ]
    }

    return where_filter


def _2asker(collection_name, query_emb, documentName, chunkUUID):

    croma_root = r"chromadb"
    # os.makedirs(os.path.join(os.getcwd(),croma_root),exist_ok=True)
    chroma_client = chromadb.PersistentClient(path=os.path.join(os.getcwd(),croma_root))
    
    croma_col = chroma_client.get_collection(name=collection_name)
    
    search_result_f = croma_col.query(query_embeddings=query_emb,
               where=where_maker(documentName, chunkUUID),
               n_results=100)
    
    #print("search_result_f \n", search_result_f)

    return search_result_f


def context_composer(orig_partNumber, filtered_result):

    # pd.set_option('display.max_colwidth', None)
    tdf = pd.DataFrame(filtered_result['metadatas'][0])
    #print(tdf)
    #print("Filtered Result", filtered_result['documents'][0])
    #print("Filtered Result", type(filtered_result['documents'][0]))
    tdf['documents'] = filtered_result['documents'][0]
    tdf.sort_values(by='partNumber', inplace=True)
    tdf.reset_index(drop=True, inplace=True)
    
    partNumber = orig_partNumber
    total_partNumber = tdf['partNumber'].nunique()

    if total_partNumber==1:
        #print("TDF Documents", tdf['documents'])
        context = list(tdf['documents'])[0]

    elif ((total_partNumber>1) & (((total_partNumber-1)-partNumber)==0)):
        context = "\n".join(tdf.tail(3)['documents'].tolist())

    elif ((total_partNumber>1) & (partNumber==0)):  
        context = "\n".join(tdf.head(3)['documents'].tolist())

    else:
        context = "\n".join(tdf.iloc[partNumber - 1 : partNumber + 2]["documents"].tolist())
        
    return context, tdf


def chunk_collation(query):

    croma_root = r"chromadb"
    # os.makedirs(os.path.join(os.getcwd(),croma_root),exist_ok=True)
    chroma_client = chromadb.PersistentClient(path=os.path.join(os.getcwd(),croma_root))
    croma_col = chroma_client.get_collection(name='RAG')
    collection = 'RAG'
    
    print("Query ------\n",query)

    query_emb = oai_embedder(query)
    result = croma_col.query(query_embeddings=query_emb, include=['documents', 'metadatas', 'distances'], n_results = 20)
    print("Result \n", result)

    #final_title_list = []
    #final_sectionHeading_list = []
    final_context_list = []
    final_document_name = []
    final_chunkUUID_name = []
    

    for dic in result["metadatas"][0]:
        
        orig_partNumber = dic['partNumber']
        #title = dic['title']
        #sectionHeading = dic['sectionHeading']
        documentName = dic['documentName']
        chunkUUID = dic["chunkUUID"]
        #print(chunkUUID)
        search_result_f = _2asker(collection, query_emb=query_emb, documentName=documentName, chunkUUID = chunkUUID)
        
        composed_chunk, chunk_df = context_composer(orig_partNumber=orig_partNumber, filtered_result=search_result_f)
        
        #final_title_list.append(title)
        #final_sectionHeading_list.append(sectionHeading)
        final_context_list.append(composed_chunk)
        final_document_name.append(documentName)
        final_chunkUUID_name.append(chunkUUID)
        #print(f'chunkUUID:{chunkUUID}---orig_part:{orig_partNumber}\n\nDF:\n{chunk_df}\nContext:{composed_chunk}\n----------------\n')

    # return final_title_list, final_sectionHeading_list, final_context_list
    print({"generated_context":{
        "composed_chunks":final_context_list,
        "document_name": final_document_name,
        "chunkUUID": final_chunkUUID_name
    }})
    return {"generated_context":{
        "composed_chunks":final_context_list,
        "document_name": final_document_name,
        "chunkUUID": final_chunkUUID_name
    }}


# chunk_collation("Optional services pricing")