import warnings
from typing import Awaitable, Callable, List, Optional, Union

from autogen_agentchat.agents import CodeExecutorAgent, UserProxyAgent
from autogen_agentchat.base import ChatAgent
from autogen_agentchat.teams import MagenticOneGroupChat
from autogen_core import CancellationToken
from autogen_core.models import ChatCompletionClient

from autogen_ext.agents.file_surfer import FileSurfer
from autogen_ext.agents.magentic_one import MagenticOneCoderAgent
from autogen_ext.agents.web_surfer import MultimodalWebSurfer
from autogen_ext.code_executors.local import LocalCommandLineCodeExecutor
from autogen_ext.models.openai._openai_client import BaseOpenAIChatCompletionClient
from addon_agents import DataIngestionAgent,QueryProcessingAgent
import os

SyncInputFunc = Callable[[str], str]
AsyncInputFunc = Callable[[str, Optional[CancellationToken]], Awaitable[str]]
InputFuncType = Union[SyncInputFunc, AsyncInputFunc]


class MagenticOne(MagenticOneGroupChat):
    """
    References:
        .. code-block:: bibtex

            @article{fourney2024magentic,
                title={Magentic-one: A generalist multi-agent system for solving complex tasks},
                author={Fourney, Adam and Bansal, Gagan and Mozannar, Hussein and Tan, Cheng and Salinas, Eduardo and Niedtner, Friederike and Proebsting, Grace and Bassman, Griffin and Gerrits, Jack and Alber, Jacob and others},
                journal={arXiv preprint arXiv:2411.04468},
                year={2024},
                url={https://arxiv.org/abs/2411.04468}
            }
    """

    def __init__(
        self,
        client: ChatCompletionClient,
        hil_mode: bool = False,
        input_func: InputFuncType | None = None,
        tools: List=[],
        web_surfer_required: bool = False,
        file_surfer_required: bool = False,
        knowledge_assist_required: bool = True
    ):
        self.client = client
        self._validate_client_capabilities(client)
        work_path=os.path.join(os.getcwd(),"magentic_logs")
        screenshot_path=os.path.join(work_path,"screenshots")
        execution_path=os.path.join(work_path,"code")
        os.makedirs(screenshot_path,exist_ok=True)
        os.makedirs(execution_path,exist_ok=True)
        coder = MagenticOneCoderAgent("Coder", model_client=client)
        #coder = CoderAgent("Coder", model_client=client)
        executor = CodeExecutorAgent("Executor", code_executor=LocalCommandLineCodeExecutor(work_dir=execution_path))
        agents: List[ChatAgent] = [coder, executor]

        ka = QueryProcessingAgent("QueryProcessingAgent",model_client=client)
        agents.append(ka)
        if len(tools)>0:
            tool=DataIngestionAgent("DataIngestionAgent",model_client=client,tools=tools)
            agents.append(tool)
        print('Agents Involved', agents)
        super().__init__(agents, model_client=client)

    def _validate_client_capabilities(self, client: ChatCompletionClient) -> None:
        capabilities = client.model_info
        required_capabilities = ["vision", "function_calling", "json_output"]

        if not all(capabilities.get(cap) for cap in required_capabilities):
            warnings.warn(
                "Client capabilities for MagenticOne must include vision, " "function calling, and json output.",
                stacklevel=2,
            )

        if not isinstance(client, BaseOpenAIChatCompletionClient):
            warnings.warn(
                "MagenticOne performs best with OpenAI GPT-4o model either " "through OpenAI or Azure OpenAI.",
                stacklevel=2,
            )
