import time
import os
import numpy as np
import hashlib
import uuid
import time
import random
import datetime

from os.path import basename, join
# from helpers.abstract_bulk_runner import AbstractBulkRunner
# from src.pipeline_executor import Executor
import streamlit as st
# from utils.tags import Tag
import json
import pandas as pd
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from langchain.text_splitter import TokenTextSplitter
import base64
import openai
import tiktoken

# endpoint = "https://form-recognizer-integra-poc.cognitiveservices.azure.com/"
# key = "5f0f768789374736a82d2ee113b8339e"
# document_analysis_client = DocumentAnalysisClient(endpoint=endpoint, credential=AzureKeyCredential(key))
# openai.api_type = 'azure'
# openai.api_base = "https://aoai-ais-aicoe-llm.openai.azure.com/"
# openai.api_version = "2023-03-15-preview"
# openai.api_key = '2f59100dce0340e08c28620582db241a'

collection_name = 'chunker'


def num_tokens_from_string(string: str, encoding_name: str) -> int:
    """Returns the number of tokens in a text string."""
    encoding = tiktoken.get_encoding(encoding_name)
    num_tokens = len(encoding.encode(string))
    return num_tokens

# def doc_recognizer(root_dir):
#     endpoint = "https://form-recognizer-integra-poc.cognitiveservices.azure.com/"
#     credential = AzureKeyCredential("5f0f768789374736a82d2ee113b8339e")
#     document_analysis_client = DocumentAnalysisClient(endpoint, credential)
#     content_list = []
#     file_names = os.listdir(root_dir)
#     for file in file_names:
#         fpath = os.path.join(root_dir, file)
#         with open(fpath, "rb") as doc:
#             azure_poller = document_analysis_client.begin_analyze_document(model_id='prebuilt-layout', document=doc)
#             analysed_doc = azure_poller.result()
#         fname = file.split(".")[0].strip()
#         result_dic = {'filename':fname, 'content':analysed_doc.content}
#         content_list.append(result_dic)
#     return content_list

def write_files(dir, files):
    present_input_files = os.listdir(dir)
    present_output_files = os.listdir(os.path.join(dir, 'generated_output'))
    for filename in present_input_files:
        try:
            os.remove(os.path.join(dir, filename))
        except:
            pass
    # for filename in present_output_files:
    #     try:
    #         os.remove(os.path.join(dir, 'generated_output', filename))
    #     except:
    #         pass

    for file in files:
        # print(file.name)
        # content = file.read()
        with open(os.path.join(dir, file.name), 'wb') as bf:
            bf.write(file.getvalue())


def tab2context(tab_obj):
    tot_row = tab_obj['row_count']
    tot_col = tab_obj['column_count']
    refmat = np.char.chararray(shape=(tot_row, tot_col), unicode=True, itemsize=600)
    all_vals = []
    for cell in tab_obj["cells"]:
        try:
            rowspan = cell["row_span"]
            colspan = cell["column_span"]
            all_vals.append({'row': cell['row_index'], 'column': cell['column_index'],
                             'kind': cell['kind'], 'content': cell['content'], 'rowspan': rowspan, 'colspan': colspan})
        except:
            all_vals.append({'row': cell['row_index'], 'column': cell['column_index'],
                             'kind': cell['kind'], 'content': cell['content'], 'rowspan': 1, 'colspan': 1})
    df = pd.DataFrame(all_vals)
    for ix in df.index:
        row = df.loc[ix]['row']
        col = df.loc[ix]['column']
        content = df.loc[ix]['content']
        rspan = df.loc[ix]['rowspan']
        cspan = df.loc[ix]['colspan']
        for curow in range(row, (row + rspan)):
            refmat[curow][col] = content

        for curcol in range(col, (col + cspan)):
            refmat[row][curcol] = content
    res_df = pd.DataFrame(refmat.tolist())
    tab_text = ''
    if 'columnheader' in df.kind.str.lower().tolist():
        head_ix = df[df.kind.str.lower().str.contains('columnheader')]['row'][0]
        res_df.columns = res_df.loc[head_ix].tolist()
        res_df.drop(index=head_ix, inplace=True)
        #         tab_text = ''
        tab_text = '\n\n'.join(
            '\n'.join(f'{k} - {v}' for k, v in res_df.loc[ix].to_dict().items()) for ix in res_df.index)
        return tab_text
    else:
        #         tab_text = ''
        for ix in res_df.index:
            tab_text = tab_text + '\n'.join(res_df.loc[ix].values.tolist()) + '\n\n'
        return tab_text


def tab2context_v1(tab_obj, return_df=False):
    tot_row = tab_obj['row_count']
    tot_col = tab_obj['column_count']

    refmat = np.char.chararray(shape=(tot_row, tot_col), unicode=True, itemsize=600)
    # print("refmat : ", refmat)

    all_vals = []
    for cell in tab_obj["cells"]:
        try:
            rowspan = cell["row_span"]
            colspan = cell["column_span"]
            all_vals.append({'row': cell['row_index'], 'column': cell['column_index'],
                             'kind': cell['kind'], 'content': cell['content'], 'rowspan': rowspan, 'colspan': colspan})
        except:
            all_vals.append({'row': cell['row_index'], 'column': cell['column_index'],
                             'kind': cell['kind'], 'content': cell['content'], 'rowspan': 1, 'colspan': 1})

    df = pd.DataFrame(all_vals)
    # print("table  : df : ", df)

    for ix in df.index:
        row = df.loc[ix]['row']
        col = df.loc[ix]['column']
        content = df.loc[ix]['content']
        rspan = df.loc[ix]['rowspan']
        cspan = df.loc[ix]['colspan']

        for curow in range(row, (row + rspan)):
            refmat[curow][col] = content

        for curcol in range(col, (col + cspan)):
            refmat[row][curcol] = content

    res_df = pd.DataFrame(refmat.tolist())
    tab_text = ''

    head_list = df[df.kind.str.lower().str.contains('columnheader')]['content'].tolist()
    valid_heads = [head for head in head_list if head]
    flag = True
    if head_list and head_list[0] and len(valid_heads)<2:
        flag = False

    if ('columnheader' in df.kind.str.lower().tolist()) and flag:
        # print('columnheader present')
        head_ix = df[df.kind.str.lower().str.contains('columnheader')]['row'][0]
        res_df.columns = res_df.loc[head_ix].tolist()
        res_df.drop(index=head_ix, inplace=True)
        #         tab_text = ''
        # tab_text = '\n\n'.join('\n'.join(f'{k} - {v}' for k, v in res_df.loc[ix].to_dict().items()) for ix in res_df.index)

        for rx in res_df.index:
            if ('' in res_df.loc[rx].values.tolist()):
                st_ix = res_df.loc[rx].values.tolist().index('') - 1
                tab_text = tab_text + '\n\n' + res_df.loc[rx].values.tolist()[st_ix] + '\n'
            elif (len(set(res_df.loc[rx].values.tolist())) == 1):
                tab_text = tab_text + '\n\n' + res_df.loc[rx].values.tolist()[0] + '\n'
            else:
                valid_rows = [i for i in res_df.columns.tolist() if i]
                if set(map(type, res_df.columns.tolist())) == {int} or len(valid_rows)<2:
                    tab_text = tab_text + '\n'.join(res_df.loc[rx].values.tolist()) + '\n\n'
                else:
                    tab_text = tab_text + (
                        '\n'.join([f'{k} - {v}' for k, v in res_df.loc[rx].to_dict().items()])) + '\n'

        if return_df:
            return tab_text, res_df
        else:
            return tab_text
    else:
        # print('columnheader absent')
        #         tab_text = ''
        for rx in res_df.index:
            if ('' in res_df.loc[rx].values.tolist()):
                st_ix = res_df.loc[rx].values.tolist().index('') - 1
                tab_text = tab_text + '\n\n' + res_df.loc[rx].values.tolist()[st_ix] + '\n'
            elif (len(set(res_df.loc[rx].values.tolist())) == 1):
                tab_text = tab_text + '\n\n' + res_df.loc[rx].values.tolist()[0] + '\n'
            else:
                if set(map(type, res_df.columns.tolist())) == {int}:
                    tab_text = tab_text + '\n'.join(res_df.loc[rx].values.tolist()) + '\n\n'
                else:
                    tab_text = tab_text + (
                        '\n'.join([f'{k} - {v}' for k, v in res_df.loc[rx].to_dict().items()])) + '\n'
                # tab_text = tab_text + ('\n'.join([f'{k} - {v}' for k, v in res_df.loc[rx].to_dict().items()]))+'\n'

        if return_df:
            return tab_text, res_df
        else:
            return tab_text


@st.cache_data
def convert_df(df):
    # IMPORTANT: Cache the conversion to prevent computation on every rerun
    return df.to_csv().encode('utf-8')


def ocr_files(folder, fileName, azureEndpoint, azureKey):
    # endpoint = "https://form-recognizer-integra-poc.cognitiveservices.azure.com/"
    # credential = AzureKeyCredential("5f0f768789374736a82d2ee113b8339e")
    endpoint = azureEndpoint
    credential = AzureKeyCredential(azureKey)
    document_analysis_client = DocumentAnalysisClient(endpoint, credential)
    all_files = []
    all_files.append(fileName)
    # all_files = [file for file in os.listdir(folder) if file.endswith("pdf")]
    # all_files = [file for file in os.listdir(folder) if file.endswith("pdf")]
    # print("all_files : ", all_files)
    ocr_files = []
    for file in all_files:
        ocr_files.append(os.path.join(folder, "generated_output", file + ".json"))
        if not os.path.exists(os.path.join(folder, "generated_output", file + ".json")):
            path_to_sample_documents = os.path.join(folder, file)
            with open(path_to_sample_documents, "rb") as f:
                poller = document_analysis_client.begin_analyze_document("prebuilt-layout", document=f)
                result = poller.result()
                with open(os.path.join(folder, "generated_output", file + ".json"), "w") as fw:
                    fw.write(json.dumps(result.to_dict(), indent=4))
    return ocr_files

def sha256sum(filename):
    with open(filename, "rb") as f:
        bytes = f.read()  # read entire file as bytes
        readable_hash = hashlib.sha256(bytes).hexdigest();
        return readable_hash

def smart_chunker(folder, fileName, sessionRequestID,cloudName, azureEndpoint, azureKey, chunkTokenSize):

    start_time = time.time()

    file_path = os.path.join(folder, fileName)
    # print("file_path : ", file_path)
    sha256Sum_id = sha256sum(file_path)
    chunkEmbeddingFlag = False
    files = ocr_files(folder, fileName, azureEndpoint, azureKey)
    # print("files : : :", files)
    chunker_Dict = {}

    # You can display or further analyze the processed contents here
    # generated_jsons = [doc for doc in os.listdir(os.path.join(folder, 'generated_output'))
    #                    if doc.endswith("json")]
    generated_jsons = files
    folder_doc_chunker = {}
    num_doc = 0
    doc_chunker_df_dict = {}
    doc_name_list = []
    docTitle_list = []
    pageNumber_list = []
    paraContent_list = []
    paraHeading_list = []
    paraPartNumber_list = []
    embeddings_list = []
    for generated_json, doc_tab in zip(generated_jsons, st.tabs(generated_jsons)):
        document_chunker = {}
        # print("generated_json : ", generated_json)
        num_doc =  num_doc + 1
        with doc_tab:
            file_name = generated_json
            with open(generated_json, 'r', encoding='utf-8') as j:
                contents = json.loads(j.read())
                # print(contents)
            # fp_json = contents["paragraphs"]
            # df = pd.DataFrame(columns=["document_name", "document_type", "text", "page", "category", "part_id"])
            df = pd.DataFrame(
                columns=["document_name", "document_type", "text", "page", "Xmin", "Ymin", "Xmax", "Ymax",
                         "Xcent", "Ycent", "category", "part_id", "content_type"])
            index = 1
            old_category = None
            part_id = 0
            # GET ALL DATA FROM PARAGRAPHS
            # print("all paragraphs : ", len(contents["paragraphs"]))
            for para in contents["paragraphs"]:

                # print("para : ", para)

                doc_name = "sample_document.pdf"
                doc_type = "NA"
                text = para["content"]
                content_type = "text"
                category = "NA"
                try:
                    category = para["role"]
                    if category == "footnote":
                        category = "NA"
                    elif category == None:
                        category = "NA"
                except:
                    pass
                if old_category != category:
                    part_id += 1
                old_category = category
                pages = []
                Xmins = []
                Ymins = []
                Xmaxs = []
                Ymaxs = []
                for region in para["bounding_regions"]:
                    pages.append(region["page_number"])
                    # polygons.append(region["polygon"])
                    Xmins.append(region["polygon"][0]["x"])
                    Ymins.append(region["polygon"][0]["y"])
                    Xmaxs.append(region["polygon"][2]["x"])
                    Ymaxs.append(region["polygon"][2]["y"])
                # page = ",".join(pages)
                # polygon = ",".join(polygons)
                Xcent = (Xmins[0] + Xmaxs[0]) / 2.0
                Ycent = (Ymins[0] + Ymaxs[0]) / 2.0
                df.loc[index] = [doc_name, doc_type, text, pages[0], Xmins[0], Ymins[0], Xmaxs[0], Ymaxs[0],
                                 Xcent, Ycent, category, part_id, content_type]
                index += 1
            df = df.sort_index(ascending=True)
            df.drop(df[df.category == "pageHeader"].index, inplace=True)
            df.drop(df[df.category == "pageFooter"].index, inplace=True)
            df.drop(df[df.category == "pageNumber"].index, inplace=True)
            # GET ALL DATA FROM PARAGRAPHS
            # print("Table Content : ", len(contents["tables"]))
            for para in contents["tables"]:
                content_type = "table"
                # print("para : :: ", para)
                flatten_table = tab2context_v1(para)
                # print("flatten_table : ", flatten_table)
                flatten_table = "<br>******Table Content********<br>" + flatten_table.strip().replace('\n',
                                                                                                      '<br>') + "<br>**************<br>"
                # flatten_table = flatten_table.strip().replace('\n','<br>')
                for region in para["bounding_regions"]:
                    page = region["page_number"]
                    Xmin = region["polygon"][0]["x"]
                    Ymin = region["polygon"][0]["y"]
                    Xmax = region["polygon"][2]["x"]
                    Ymax = region["polygon"][2]["y"]
                    rslt_df = df[df['page'] == page]
                    # filtered_df = df[(df['page'] == page) & (df['Xmin'] >= Xmin) & (df['Ymin'] >= Ymin) & (df['Xmax'] <= Xmax) & (df['Ymax'] <= Ymax)]
                    filtered_df = df[(df['page'] == page) & (df['Xcent'] >= Xmin) & (df['Ycent'] >= Ymin) & (
                            df['Xcent'] <= Xmax) & (
                                             df['Ycent'] <= Ymax)]
                    indices_to_set = filtered_df.index
                    df.loc[indices_to_set[0], 'text'] = flatten_table
                    df.loc[indices_to_set[0], 'content_type'] = content_type
                    df.loc[indices_to_set[0], 'category'] = 'NA'
                    df.drop(indices_to_set[1:], inplace=True)
            grouped = df.groupby(["document_name", "document_type", "page", "category", "part_id","content_type"])[
                "text"].apply("\n".join).reset_index().sort_values(["part_id"]).reset_index(drop=True)
            hierarchy_dfs = []
            title = None
            sectionHeading = None
            for loc in range(len(grouped)):
                category = grouped.loc[loc]["category"]
                # print(category)
                if category == "title":
                    title = grouped.loc[loc]["text"]
                    sectionHeading = None
                elif category == "sectionHeading":
                    # print("It is here!!")
                    sectionHeading = grouped.loc[loc]["text"]
                else:
                    # print("Sectionheading name:", sectionHeading)
                    hierarchy_dfs.append({"title": title, "sectionHeading": sectionHeading,
                                          "paraContent": grouped.loc[loc]["text"],
                                          "pageNumber": grouped.loc[loc]["page"],
                                          "contentType": grouped.loc[loc]["content_type"]})

            df2 = pd.DataFrame(hierarchy_dfs)
            # import openai
            # s1 = st.slider("Chunk Size (No of Tokens)", min_value=50, max_value=2000, value=100, step=50)
            s1 = st.slider("Chunk Size (No of Tokens)", min_value=50, max_value=2000, value=chunkTokenSize, step=50)
            text_splitter = TokenTextSplitter(chunk_size=s1, chunk_overlap=0)
            chunk_dfs = pd.DataFrame(
                columns=["title", "sectionHeading", "paraContent", "pageNumber", "contentType", "partNumber", "totalPartNumber","UUID"])
            old_title = None
            old_heading = None
            # part_number = 0
            # chunk_dfs_ind = 0
            # print("len(df2) : ", len(df2))
            # part_number = 0
            chunk_dfs_ind = 0

            for ind in range(len(df2)):
                part_number = 0
                # chunk_dfs_ind = 0
                row = df2.loc[ind]
                cur_title = row["title"]
                cur_heading = row["sectionHeading"]
                if old_title != cur_title or old_heading != cur_heading:
                    part_number = 0
                old_title = cur_title
                old_heading = cur_heading
                para_content = row["paraContent"]
                split_texts = text_splitter.split_text(para_content)
                # print("len of split_texts : ", len(split_texts))
                content_type = row["contentType"]
                # print("content_type : ", content_type)
                # chunkUUID = uuid.uuid4()
                # id = uuid.uuid1()
                id = uuid.uuid4()
                chunkUUID = str(id)
                totalPartNumber = len(split_texts)
                for split in split_texts:
                    new_row = row.tolist()
                    # print("new_row : ", new_row)
                    new_row[2] = split
                    new_row.append(part_number)
                    new_row.append(totalPartNumber)
                    # new_row.append(content_type)
                    new_row.append(chunkUUID)
                    chunk_dfs.loc[chunk_dfs_ind] = new_row
                    chunk_dfs_ind += 1
                    part_number += 1

                # chunk_dfs["TotalPartNumber"] = part_number
            df2 = chunk_dfs
        doc_chunker = []
        filename_ext = os.path.basename(file_name)
        # print("filename_ext : ", filename_ext)
        chunk_Id = 1
        for index_chunk, row in df2.iterrows():
            chunk_temp_dict = {}
            id_file = uuid.uuid1()
            chunkUUID_file = id_file.int
            # chunkId = filename_ext +"_"+ str(chunk_Id)
            chunkId = str(sha256Sum_id)[:5] +"-"+ str(chunkUUID)[5:] + "-"+ str(random.randint(100, 999)) + "-" + str(chunkUUID_file)[:5]
            # chunkId = str(sha256Sum_id[:5]) +"-"+ str(chunkUUID[5:]) + "-"+ str(random.randint(100, 999)) + "-" + str(chunkUUID_file[:5])
            chunk_temp_dict["id"] = chunkId
            chunk_temp_dict["documentClass"] = ""
            chunk_temp_dict["title"] = row[0]
            chunk_temp_dict["sectionHeading"] = row[1]
            # print("para content : ", row[2])
            token_count = num_tokens_from_string(row[2], "cl100k_base")
            # ner_entity = NER_Detection(row[2])
            chunk_temp_dict["content"] = row[2]
            chunk_temp_dict["partNumber"] = row[5]
            chunk_temp_dict["totalPartNumber"] = row[6]
            chunk_temp_dict["chunkUUID"] = row[7]
            chunk_temp_dict["pageNumber"] = row[3]
            chunk_temp_dict["tokenCount"] = token_count
            chunk_temp_dict["chunkType"] = row[4]
            chunk_temp_dict["chunkBoundingBox"] = ""
            chunk_Id = chunk_Id + 1
            # chunk_temp_dict["NER"] = ner_entity
            doc_chunker.append(chunk_temp_dict)

            doc_name_list.append(filename_ext)
            docTitle_list.append(row[0])
            pageNumber_list.append(row[3])
            paraContent_list.append(row[2])
            paraHeading_list.append(row[1])
            paraPartNumber_list.append(row[4])
            if chunkEmbeddingFlag :
                emb_response = openai.Embedding.create(input=row[2], engine='text-embedding-ada-002')
                chunk_temp_dict["embedding"] = emb_response["data"][0]["embedding"]
                embeddings_list.append(emb_response["data"][0]["embedding"])
            # print("Index : ", index)
            # print("row : ", row)
            # print("docTitle : ", row[0])
            # print("paraHeading  : ", row[1])
            # print("paraContent  : ", row[2])
            # print("pageNumber  : ", row[3])
            # print("paraPartNumber  : ", row[4])

        df2.to_json('Out_Response.json')
        # print("doc_chunker : ", doc_chunker)
        # print("file_name : ", file_name)
        head, tail = os.path.split(file_name)
        # print("head : ", head)
        # print("tail : ", tail)

        filenme = os.path.splitext(tail)[0]
        # print("file_name : ", filenme)
        file_type = os.path.splitext(filenme)[1]
        # print("File_Type  : ", file_type)


        # start = '\\'
        # end = '.json'
        # s = file_name
        # file_nme = s[s.find(start) + len(start):s.rfind(end)]
        # print("File name : ", file_nme)
        # doc_chunker["file_name"] = file_nme

        chunkerMetadata = {}
        chunkerMetadata["tokenizer"] = "tiktoken"
        chunkerMetadata["tokenizerVersion"] = "version"
        chunkerMetadata["ocrModel"] = "azure"
        chunkerMetadata["ocrVersion"] = "version"
        chunkerMetadata["layoutModel"] = "azure"
        chunkerMetadata["layoutModelVersion"] = "azureVersion"
        chunkerMetadata["chunkerVersion"] = "version"

        operationalMetrics = {}
        end_time = time.time()
        operationalMetrics["uploadedDateTime"] = "uploaded Time"
        operationalMetrics["processingStartTime"] = start_time
        operationalMetrics["processingEndTime"] = end_time
        operationalMetrics["sessionRequestID"] = sessionRequestID


        filePropDict = {}
        filePropDict["fileName"] = filenme
        filePropDict["fileType"] = file_type
        filePropDict["sha256Sum"] = sha256Sum_id
        document_chunker["fileProperties"] = filePropDict
        document_chunker["chunkerMetadata"] = chunkerMetadata
        document_chunker["operationalMetrics"] = operationalMetrics
        # document_chunker["fileName"] = filenme
        # document_chunker["fileType"] = file_type
        document_chunker["chunkData"] = doc_chunker

        folder_doc_chunker[filenme] = document_chunker
        # folder_doc_chunker["fileName"] = "demo.pdf"
        # folder_doc_chunker[num_doc] = doc_chunker

    if chunkEmbeddingFlag:
        doc_chunker_df_dict = {"fileName": doc_name_list, "docTitle": docTitle_list, "paraHeading": paraHeading_list,
                               "paraContent": paraContent_list, "paraPartNumber": paraPartNumber_list,
                               "pageNumber": pageNumber_list, "embeddings": embeddings_list}
    else:
        doc_chunker_df_dict = {"fileName": doc_name_list, "docTitle": docTitle_list, "paraHeading": paraHeading_list,
                               "paraContent": paraContent_list, "paraPartNumber": paraPartNumber_list,
                               "pageNumber": pageNumber_list}
    df_all_data = pd.DataFrame(doc_chunker_df_dict)
    # df_all_data.reset_index(inplace=True)


    # df_all_data.to_excel("chunk_milvus_embeddings_dataframe.xlsx")
    jsonFilePath = os.path.join(folder, "generated_output", filenme + ".json")
    if os.path.isfile(file_path):
        os.remove(file_path)
    if os.path.isfile(jsonFilePath):
        os.remove(jsonFilePath)

    return folder_doc_chunker


# if __name__ == "__main__":
#     # fold_name = "D:\Ready_made_Code\Document_Extractor_Using_LLM/uploaded_data/"
#     fold_name = "D:\Ready_made_Code\Doc_Chunker_api/uploaded_data/"
#     smart_chunker(fold_name)
