import json
import traceback
import time
from typing import List, Optional, Tuple,Sequence
import sqlite3
import os
from autogen_core import CancellationToken, FunctionCall, default_subscription
from autogen_agentchat.agents import BaseChatAgent
from autogen_agentchat.base import Response
from autogen_agentchat.messages import (
    ChatMessage,
    MultiModalMessage,
    TextMessage,
)
from autogen_core.models import (
    AssistantMessage,
    ChatCompletionClient,
    LLMMessage,
    SystemMessage,
    UserMessage,
)
from autogen_core.tools import ToolSchema,ParametersSchema

# from utilities import parse_documents
from data_ingest import extract_and_chunk
from embeddings_creator import create_croma_embedings
from typing import Any, Dict

############## Setup Tool Agent

def _load_tool(tooldef: Dict[str, Any]) -> ToolSchema:
    #print(tooldef)
    if tooldef["function"]["name"]=="extract_and_chunk_text":
        return ToolSchema(
            name=tooldef["function"]["name"],
            description=tooldef["function"]["description"],
            parameters=ParametersSchema(
                type="object",
                properties=tooldef["function"]["parameters"]["properties"],
                required=tooldef["function"]["parameters"]["required"],
            ),
        )
    elif tooldef["function"]["name"]=="generate_embeddings_and_store":
        return ToolSchema(
            name=tooldef["function"]["name"],
            description=tooldef["function"]["description"],
            parameters=ParametersSchema(
                type="object",
                properties=tooldef["function"]["parameters"]["properties"],
                required=tooldef["function"]["parameters"]["required"],
            ),
        )

with open(os.path.join(os.getcwd(),"common_tools.json"),"r") as f:
    file_agent_def=json.loads(f.read())["extract_and_chunk_text"]


with open(os.path.join(os.getcwd(),"common_tools.json"),"r") as f:
    embeddings_creator = json.loads(f.read())["generate_embeddings_and_store"]

class DataIngestionAgent(BaseChatAgent):
    """An agent that automates document ingestion by extracting text, chunking content, generating embeddings, and storing them in a vector database."""

    DEFAULT_DESCRIPTION = "An agent that automates document ingestion by extracting text, chunking content, generating embeddings, and storing them in a vector database for efficient retrieval."

    DEFAULT_SYSTEM_MESSAGES = [
        SystemMessage(
            content="""
        You are a Data Ingestion Agent responsible for processing documents. 
        Your primary tasks include:
        - Extracting text from documents.
        - Splitting the extracted text into meaningful chunks.
        - Generating embeddings for the chunked content.
        - Storing embeddings in a vector database.

        Always use the available tools to complete your tasks. If a tool is not available, respond with:
        'I can't perform the given task.'

        Do not provide additional explanations or responses outside of your designated tasks.
        """
        ),
    ]

    def __init__(
        self,
        name: str,
        model_client: ChatCompletionClient,
        description: str = DEFAULT_DESCRIPTION,
        system_messages: List[SystemMessage] = DEFAULT_SYSTEM_MESSAGES,
        tools: List[ToolSchema] = [],
    ) -> None:        
        self._tools = []
        self._funcdefs={}
        # for key in tools:
        #     self._tools.append(_load_tool(tools[key]["schema"]))
        #     self._funcdefs[key]=tools[key]["code"]
        #     print("Function Load:",key)
        self._tools.append(_load_tool(file_agent_def))
        self._tools.append(_load_tool(embeddings_creator))
        #self._funcdefs["parse_documents"]=parse_documents
        print("Function Load: extract_and_chunk_text")
        print("Function Load: generate_embeddings_and_store")
        print(self._tools)
        description=description + "Below is the list of available tools:\n" + "\n".join([elem['name'] + ": " +  elem['description'] for elem in self._tools])
        super().__init__(name,description)
        self._model_client = model_client
        self._system_messages = system_messages
        self._chat_history: List[LLMMessage] = []

    @property
    def produced_message_types(self) -> Sequence[type[ChatMessage]]:
        return (TextMessage,)
        
    async def on_messages(self, messages: Sequence[ChatMessage], cancellation_token: CancellationToken) -> Response:
        for chat_message in messages:
            if isinstance(chat_message, TextMessage | MultiModalMessage):
                self._chat_history.append(UserMessage(content=chat_message.content, source=chat_message.source))
            else:
                raise ValueError(f"Unexpected message in ToolAgent: {chat_message}")

        try:
            _, content = await self._generate_reply(cancellation_token=cancellation_token)
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

        except BaseException:
            content = f"Tool Agent error:\n\n{traceback.format_exc()}"
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

    async def on_reset(self, cancellation_token: CancellationToken) -> None:
        self._chat_history.clear()

    async def _generate_reply(self, cancellation_token: CancellationToken) -> Tuple[bool, str]:
        history = self._chat_history[0:-1]
        #print("History")
        #print(history)
        last_message = self._chat_history[-1]
        assert isinstance(last_message, UserMessage)

        task_content = last_message.content  # the last message from the sender is the task

        task_message = UserMessage(
            source="user",
            content=task_content,
        )
        #print(history)
        #print(task_message)
        create_result = await self._model_client.create(
            messages=self._system_messages + history + [task_message], tools=self._tools, cancellation_token=cancellation_token
        )

        response = create_result.content
        #print("Tool Agent")
        print(response)
        if isinstance(response, str):
            return False, response

        elif isinstance(response, list) and all(isinstance(item, FunctionCall) for item in response):
            #print(response)
            function_calls = response
            final_response=""
            for function_call in function_calls:
                tool_name = function_call.name

                try:
                    arguments = json.loads(function_call.arguments)
                except json.JSONDecodeError as e:
                    error_str = f"Tool Agent encountered an error decoding JSON arguments: {e}"
                    return False, error_str
                
                if tool_name=="extract_and_chunk_text":
                    fuction_to_call=extract_and_chunk
                elif tool_name=="generate_embeddings_and_store":
                    fuction_to_call=create_croma_embedings
                #print(*list(arguments.values()))
                response_message = fuction_to_call(*list(arguments.values()))
                #print(response_message)
                final_response = final_response + response_message
            return False, final_response

        final_response = "TERMINATE"
        return False, final_response

############## Setup RAG Agent

class QueryProcessingAgent(BaseChatAgent):
    """An agent that can access enterprise knowledge sources (vector store) to retrieve relevant context and answer user queries accurately."""

    DEFAULT_DESCRIPTION = "An agent that can answer user queries by retrieving relevant context from a vector store and generating concise, accurate responses based on available enterprise information."

    DEFAULT_SYSTEM_MESSAGES = [
        SystemMessage(
            content= """
        You are an AI-powered Query Processing Agent.
        Your primary tasks include:
        - Answering user queries based on retrieved knowledge.
        - Generating concise summaries from provided documents.

        If no relevant information is found, respond by saying:
        'I do not have enough information to answer this question.'

        Do not provide additional assumptions or fabricate responses.
        """
        ),
    ]

    def __init__(
        self,
        name: str,
        model_client: ChatCompletionClient,
        description: str = DEFAULT_DESCRIPTION,
        system_messages: List[SystemMessage] = DEFAULT_SYSTEM_MESSAGES,
        tools: List[ToolSchema] = [],
    ) -> None:        
        self._tools = []
        self._funcdefs={}
        super().__init__(name,description)
        self._model_client = model_client
        self._system_messages = system_messages
        self._chat_history: List[LLMMessage] = []

    @property
    def produced_message_types(self) -> Sequence[type[ChatMessage]]:
        return (TextMessage,)
        
    async def on_messages(self, messages: Sequence[ChatMessage], cancellation_token: CancellationToken) -> Response:
        for chat_message in messages:
            if isinstance(chat_message, TextMessage | MultiModalMessage):
                self._chat_history.append(UserMessage(content=chat_message.content, source=chat_message.source))
            else:
                raise ValueError(f"Unexpected message in ToolAgent: {chat_message}")

        try:
            _, content = await self._generate_reply(cancellation_token=cancellation_token)
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

        except BaseException:
            content = f"Tool Agent error:\n\n{traceback.format_exc()}"
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

    async def on_reset(self, cancellation_token: CancellationToken) -> None:
        self._chat_history.clear()

    async def _generate_reply(self, cancellation_token: CancellationToken) -> Tuple[bool, str]:
        history = self._chat_history[0:-1]
        #print("History")
        #print(history)
        last_message = self._chat_history[-1]
        assert isinstance(last_message, UserMessage)

        task_content = last_message.content  # the last message from the sender is the task
        
        chat_history=[]
        #print("\n\n\n######################### HISTORY ########################")
        for elem in history:
            chat_history.append({"role":"assistant","content":elem.source + ": " + elem.content})
        #print(chat_history)
        #print("######################### HISTORY END########################\n\n\n") """

        from wega_chat import get_llm_output
        result=get_llm_output({
            "instructions":"\n".join([elem.content for elem in self._system_messages]),
            "chat_history":chat_history,
            "query":task_content
        })
        #print("###################### RESULT #############################")
        #print(result)
        #print("###################### RESULT #############################")
        response=result.choices[0].message.content.strip()

        #print("Tool Agent")
        #print(response)
        if isinstance(response, str):
            return False, response

        final_response = "TERMINATE"
        return False, final_response

############## Setup Coder Agent

from autogen_agentchat.agents import AssistantAgent
from autogen_core.models import (
    ChatCompletionClient,
)

CODER_AGENT_DESCRIPTION = "A helpful and general-purpose AI assistant that has strong Python skills, and Linux command line skills."

CODER_AGENT_SYSTEM_MESSAGE = """You are a helpful AI assistant.
Solve tasks using your coding and language skills.
In the following cases, suggest python code (in a python coding block) or shell script (in a sh coding block) for the user to execute.
    1. When you need to collect info, use the code to output the info you need, for example, browse or search the web, download/read a file, print the content of a webpage or a file, get the current date/time, check the operating system. After sufficient info is printed and the task is ready to be solved based on your language skill, you can solve the task by yourself.
    2. When you need to perform some task with code, use the code to perform the task and output the result. Finish the task smartly.
Solve the task step by step if you need to. If a plan is not provided, explain your plan first. Be clear which step uses code, and which step uses your language skill.
When using code, you must indicate the script type in the code block. The user cannot provide any other feedback or perform any other action beyond executing the code you suggest. The user can't modify your code. So do not suggest incomplete code which requires users to modify. Don't use a code block if it's not intended to be executed by the user.
If you want the user to save the code in a file before executing it, put # filename: <filename> inside the code block as the first line. Don't include multiple code blocks in one response. Do not ask users to copy and paste the result. Instead, use 'print' function for the output when relevant. Check the execution result returned by the user.
If the result indicates there is an error, fix the error and output the code again. Suggest the full code instead of partial code or code changes. If the error can't be fixed or if the task is not solved even after the code is executed successfully, analyze the problem, revisit your assumption, collect additional info you need, and think of a different approach to try.
When you find an answer, verify the answer carefully. Include verifiable evidence in your response if possible.
Reply "TERMINATE" in the end when everything is done."""


class CoderAgent(AssistantAgent):
    """An agent, that provides coding assistance using an LLM model client."""

    def __init__(
        self,
        name: str,
        model_client: ChatCompletionClient,
        description: str = CODER_AGENT_DESCRIPTION,
        system_message: str=CODER_AGENT_SYSTEM_MESSAGE
    ):
        super().__init__(
            name,
            model_client,
            description=description,
            system_message=system_message,
        )

############## Log Handler

import logging
from autogen_core.logging import LLMCallEvent,MessageEvent,MessageDroppedEvent

class LLMUsageTracker(logging.Handler):
    def __init__(self) -> None:
        """Logging handler that tracks the number of tokens used in the prompt and completion."""
        super().__init__()
        self._prompt_tokens = 0
        self._completion_tokens = 0

    @property
    def tokens(self) -> int:
        return self._prompt_tokens + self._completion_tokens

    @property
    def prompt_tokens(self) -> int:
        return self._prompt_tokens

    @property
    def completion_tokens(self) -> int:
        return self._completion_tokens

    def reset(self) -> None:
        self._prompt_tokens = 0
        self._completion_tokens = 0

    def emit(self, record: logging.LogRecord) -> None:
        """Emit the log record. To be used by the logging module."""
        try:
            # Use the StructuredMessage if the message is an instance of it
            if isinstance(record.msg, MessageEvent):
                #print(record.msg)
                pass
            elif isinstance(record.msg, MessageDroppedEvent):
                #print(record.msg)
                pass
            elif isinstance(record.msg, LLMCallEvent):
                event = json.loads(str(record.msg))
                #print(event)
                import sqlite3
                import datetime
                import pytz
                import uuid
                conn = sqlite3.connect(os.path.join(os.getcwd(),'db','data_tables.db'))
                cursor=conn.cursor()
                cursor.execute('INSERT INTO llm_usage_logs VALUES(?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),event["agent_id"].split("/")[1],json.dumps(event["messages"]),json.dumps(event["response"]["choices"][0]["message"]["content"]),event["prompt_tokens"],event["completion_tokens"],event["response"]["model"],datetime.datetime.now(pytz.utc),))
                conn.commit()
                conn.close()
                self._prompt_tokens += event["prompt_tokens"]
                self._completion_tokens += event["completion_tokens"]
        except Exception:
            self.handleError(record)