import sqlite3
import os

def init_db():
    conn = sqlite3.connect(os.path.join(os.getcwd(),'db','data_tables.db'))  
    tables=conn.execute("select name from sqlite_schema where type='table' and name NOT LIKE 'sqlite_%'").fetchall()
    tables=[table[0] for table in tables]
        

    
    if "conv_logs" not in tables:
        conn.execute('''CREATE TABLE IF NOT EXISTS conv_logs (
                                Id TEXT,
                                conv_id TEXT,
                                team_id TEXT,
                                workflow_id TEXT,
                                message TEXT,
                                type TEXT,
                                speaker TEXT,
                                model TEXT,
                                row_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                PRIMARY KEY (Id)                        
                            );
            ''')
    
    if "llm_usage_logs" not in tables:
        conn.execute('''CREATE TABLE IF NOT EXISTS llm_usage_logs (
                                Id TEXT,
                                team_id TEXT,
                                query TEXT,
                                response TEXT,
                                prompt_tokens INTEGER,
                                completion_tokens INTEGER,
                                model TEXT,
                                row_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                PRIMARY KEY (Id)                        
                            );
            ''')
    conn.commit()
    conn.close()